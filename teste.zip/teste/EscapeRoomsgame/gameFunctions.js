//gameFunctions.js

let canvas, ctx, player, walls, door, maze, chest, monster,monster1,monster2,monster3,monster4,monster5,monster6,monsterDirection, key,key2, sword;
let monster7,monster8,key3,key4;
let keys = {};
let gameOver = false;
let images = []; // Adicione um array para armazenar as imagens carregadas
let collectedKeys = 0;
let collectedKeys2 = 0,collectedKeys3=0,collectedKeys4=0;
let totalKeys=0;
let defeatedMonsters = 0;
// Variável para rastrear se o jogador possui a espada
let hasSword = false;

// Função para carregar as imagens de forma assíncrona
export async function loadImages(paths) {
    images = await Promise.all(paths.map(async (path) => {
        return new Promise((resolve, reject) => {
            const image = new Image();
            image.onload = () => resolve(image);
            image.onerror = () => reject(new Error(`Erro ao carregar a imagem ${path}`));
            image.src = path;
        });
    }));
}

// Função de setup
export function setup() {
    canvas = document.getElementById('canvas');
    ctx = canvas.getContext('2d');
    player = { x: 50, y: 50, width: 42, height: 42 };
    walls = [{ x: 210, y: 200, width: 25, height: 300 },
        { x:120, y: 200, width: 25, height: 300 },
    ];
    door = { x: canvas.width - 75, y: canvas.height - 150, width: 50, height: 125 };
   // Modificando a matriz maze para blocos concêntricos retangulares unitários
   maze = [
    { x: 220, y: 120, width: 125, height: 25 }, // Parede esquerda
    { x: 220, y: 20, width: 25, height: 125 }, // Parede esquerda
    { x: 220, y: 0, width: 25, height: 25 }, // Parede esquerda
    { x: 140, y: 110, width: 25, height: 25 }, // Parede esquerda
    { x: 40, y: 110, width: 25, height: 300 }, // Parede esquerda
    { x: 410, y: 200, width: 25, height: 380 }, // Caminho vertical à esquerda
    { x: 290, y: 200, width: 20, height: 300 }, // Caminho vertical à direita
    { x: 310, y: 410, width: 41, height: 25 }, // Parede inferior direita
    { x: 580, y: 250, width: 211, height: 25 }, // Parede inferior direita
    { x: 440, y: 410, width: 211, height: 25 }, // Parede inferior direita
    { x: 570, y: 330, width: 281, height: 25 }, // Parede inferior direita
    { x: 570, y: 130, width: 141, height: 25 }, // Parede inferior direita
    { x: 570, y: 130, width: 25, height: 125 }, // Parede inferior direita
    { x: 470, y: 0, width: 25, height: 125 } // Parede inferior direita
    // Adicione mais blocos conforme necessário
];


    // Baú
    chest = { x: 125, y: canvas.height - 75, width: 50, height: 50 };

    // Monstro
    monster = { x: 260, y: 160, width: 32, height: 32, alive: true }; // Posicionado no túnel
monster1 = { x: 360, y: 200, width: 32, height: 32, alive: true }; // Posicionado no túnel
monster2 = { x: 10, y: 420, width: 32, height: 32, alive: true }; // Posicionado no túnel
monster3 = { x: 100, y: 10, width: 32, height: 32, alive: true }; // Posicionado no túnel
monster4 = { x: 320, y: 40, width: 32, height: 32, alive: true }; // Posicionado no túnel
monster5 = { x: 520, y: 90, width: 32, height: 32, alive: true }; // Posicionado no túnel
monster6 = { x: 220, y: 320, width: 32, height: 32, alive: true }; // Posicionado no túnel
monster7 = { x: 520, y: 320, width: 32, height: 32, alive: true }; // Posicionado no túnel
monster8 = { x: 570, y: 290, width: 32, height: 32, alive: true }; // Posicionado no túnel
// Adicionando variáveis para controlar o movimento do monstro
MONSTER_SPEED = 1; // Velocidade do monstro
monsterDirection = 1; // Direção do movimento do monstro (-1 para esquerda, 1 para direita)
monsterOriginX = monster.x; // Posição original do monstro em x
    // Chave
    key = { x: 300, y: 50, width: 32, height: 32 };
// Chave 2
key2 = { x: 380, y: 450, width: 32, height: 32 };
// Chave 3
key3 = { x: 640, y: 170, width: 32, height: 32 };
// Chave 3
 key4 = { x: 690, y: 290, width: 32, height: 32 };
    // Espada
    sword = { x: player.x+29, y: player.y+6, width: 21, height: 21 };

    window.addEventListener('keydown', e => keys[e.key] = true);
    window.addEventListener('keyup', e => keys[e.key] = false);
}
monster = { x: 260, y: 82, width: 32, height: 32 };
monster1 = { x: 360, y: 120, width: 32, height: 32 };
monster2 = { x: 10, y: 400, width: 32, height: 32 };
monster3 = { x: 100, y:10, width: 32, height: 32 };
monster4 = { x: 320, y:40, width: 32, height: 32 };
monster5 = { x: 520, y:90, width: 32, height: 32 };
monster6 = { x: 220, y:320, width: 32, height: 32 };
monster7 = { x: 520, y:320, width: 32, height: 32 };
monster8 = { x: 570, y:290, width: 32, height: 32 };
let MONSTER_SPEED = 1; // Velocidade do monstro
monsterDirection = 1; // Direção do movimento do monstro (-1 para esquerda, 1 para direita)
let monsterDirection1=1;
let monsterDirection2=1;
let monsterDirection3x=1;
let monsterDirection3y=1;
let monsterDirection4=1;
let monsterDirection5=1;
let monsterDirection6=1;
let monsterDirection7x=1;
let monsterDirection7y=1;
let monsterDirection8=1;
let monsterOriginX = monster.x; // Posição original do monstro em x
let monster1OriginY = monster.y;
let remainingHearts = 3;
// Função de atualização do monstro
function updateMonster() {
    // Movimento horizontal do monstro em um padrão de pêndulo
    monster.x += monsterDirection * MONSTER_SPEED;
    monster1.y += monsterDirection1 * MONSTER_SPEED;
    monster2.x += monsterDirection2 * MONSTER_SPEED;
    monster3.x += monsterDirection3x * MONSTER_SPEED;
    monster3.y += monsterDirection3y * MONSTER_SPEED;
    monster4.x += monsterDirection4 * MONSTER_SPEED;
    monster4.y += monsterDirection4 * MONSTER_SPEED;
    monster5.x += monsterDirection5 * MONSTER_SPEED;
    monster6.x += monsterDirection6 * MONSTER_SPEED;
    monster7.x += monsterDirection7x * MONSTER_SPEED;
    monster7.y += monsterDirection7y * MONSTER_SPEED;
    monster8.y += monsterDirection8 * MONSTER_SPEED;
    if (monster8.y>= 310) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection8 =-1;
    }
    if (monster8.y<=270) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection8 = 1;
    }
    if (monster7.x>= 420) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection7x =0;
        monsterDirection7y = -1;
    }
    if (monster7.x == 190) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection7y = -1;
        monsterDirection7x = 0;
    }if (monster7.x == 20) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection7y = 0;
        monsterDirection7x = 1;
    }
    if (monster7.x == 590) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection7x = -1;
        monsterDirection7y = 1;
    }
    if (monster7.y == 190) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection7x = -1;
        monsterDirection7y = 1;
    }
    
    if (monster6.x >= 260) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection6 = -1;
    }
    if (monster6.x <= 130) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection6 = 1;
    }
    if (monster5.x >= 570) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection5 = -1;
    }
    if (monster5.x <= 510) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection5 = 1;
    }
    if (monster4.x >= 370) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection4 = -1;
    }
    if (monster4.x <= 270) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection4 = 1;
    }
    if (monster.x >= 330) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection = -1;
    }
    if (monster.x <= 80) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection = 1;
    }
    if (monster2.x >= 56) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection2 = -1;
    }
    if (monster2.x <= 2) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection2 = 1;
    }
    if (monster1.y >= 510) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection1 = -1;
    }
    if (monster1.y <= 80) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection1 = 1;
    }
    if (monster3.x >= 180) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection3x = 0;
        monsterDirection3y = 1;
    }
    if (monster3.x <= 180) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection3x = 1;
        monsterDirection3y = 0;
    }
    if (monster3.y >= 150 && monster3.x >= 30) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection3x = -1;
        monsterDirection3y = 0;
    }
    if (monster3.x <= 30 ) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection3x = 1;
        monsterDirection3y = 0;
    }
    if (monster3.x == 30 ) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection3x = 1;
        monsterDirection3y = 1;
    }
    if (monster3.y == 230 ) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection3x = 1;
        monsterDirection3y = 0;
    }
    if (monster3.x == 530 ) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection3x = 0;
        monsterDirection3y = -1;
    }
    if (monster3.x == 330 ) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection3x = 1;
        monsterDirection3y = 0;
    }
    if (monster3.y == 35 && monster3.x >= 230) {
        // Se o monstro se afastar mais do que 100 pixels da posição original, inverte a direção
        monsterDirection3x = -1;
        monsterDirection3y = 0;
    }
}
// Função de atualização
export function update() {
    updateMonster();
    // Movimento do jogador
    if (keys['ArrowUp']) {
        player.y -= 2;
        sword.y -= 2; // Movimenta a espada junto com o jogador para cima
    }
    if (keys['ArrowDown']) {
        player.y += 2;
        sword.y += 2; // Movimenta a espada junto com o jogador para baixo
    }
    if (keys['ArrowLeft']) {
        player.x -= 2;
        sword.x -= 2; // Movimenta a espada junto com o jogador para a esquerda
    }
    if (keys['ArrowRight']) {
        player.x += 2;
        sword.x += 2; // Movimenta a espada junto com o jogador para a direita
    }
    if (hasSword) {
        sword.x = player.x + 29;
        sword.y = player.y + 6;
    }
    // Colisão com as paredes
    // Colisão com as paredes
walls.concat(maze).forEach(wall => {
    if (player.x < wall.x + wall.width &&
        player.x + player.width > wall.x &&
        player.y < wall.y + wall.height &&
        player.y + player.height > wall.y) {
            // Colisão detectada, retorna o jogador à posição inicial
            player.x = 50;
            player.y = 50;
            sword.x = player.x + 29; // Ajusta a posição da espada ao reiniciar o jogador
            sword.y = player.y + 5; // Ajusta a posição da espada ao reiniciar o jogador
            hasSword = false;
        }
});

// Função para perder vida
function loseLife() {
    const hearts = document.querySelectorAll('.heart');

    if (remainingHearts == 3) {
        hearts[2].style.display = 'none';
        remainingHearts -=1;
    }else if(remainingHearts == 2){
        hearts[1].style.display = 'none';
        remainingHearts -=1;
    }else if(remainingHearts == 1){
        hearts[0].style.display = 'none';
        remainingHearts -=1;
    }
    else if(remainingHearts === 0) {
        document.getElementById('gameOverScreen').style.display = 'block';
        document.getElementById('canvas').style.display = 'none';
    }
}
    // Colisão com o baú
    if (player.x < chest.x + chest.width &&
        player.x + player.width > chest.x &&
        player.y < chest.y + chest.height &&
        player.y + player.height > chest.y) {
            console.log('Você encontrou um baú!');
            // Adicione aqui o que acontece quando o jogador encontra o baú, como pegar a espada, por exemplo
            hasSword = true;
    }

   // Colisão com o monstro
   if ((player.x < monster.x + monster.width &&
    player.x + player.width > monster.x &&
    player.y < monster.y + monster.height &&
    player.y + player.height > monster.y) ) {
        if (hasSword) {
            console.log('Você matou o monstro!');
            defeatedMonsters++;
            // Adicione aqui o que acontece quando o jogador mata o monstro
            hasSword = false; // Remove a espada após derrotar o monstro
            monster.alive = false; // Define o monstro como morto
            monster.x = -100;
            monster.y = -100;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        } else {
            console.log('Você encontrou um monstro!');
            // Adicione aqui o que acontece quando o jogador encontra o monstro sem a espada
            player.x = 50;
            player.y = 50;
            hasSword = false;
            loseLife(); // Chama a função para perder vida
        }
} else if ((player.x < monster1.x + monster1.width &&
    player.x + player.width > monster1.x &&
    player.y < monster1.y + monster1.height &&
    player.y + player.height > monster1.y) ) {
        if (hasSword) {
            console.log('Você matou o monstro!');
            defeatedMonsters++;
            // Adicione aqui o que acontece quando o jogador mata o monstro
            hasSword = false; // Remove a espada após derrotar o monstro
            monster1.alive = false; // Define o monstro como morto
            monster1.x = -100;
            monster1.y = -100;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        } else {
            console.log('Você encontrou um monstro!');
            hasSword = false;
            // Adicione aqui o que acontece quando o jogador encontra o monstro sem a espada
            loseLife(); // Chama a função para perder vida
            player.x = 50;
            player.y = 50;
        }
} else if ((player.x < monster2.x + monster2.width &&
    player.x + player.width > monster2.x &&
    player.y < monster2.y + monster2.height &&
    player.y + player.height > monster2.y) ) {
        if (hasSword) {
            console.log('Você matou o monstro!');
            defeatedMonsters++;
            // Adicione aqui o que acontece quando o jogador mata o monstro
            hasSword = false; // Remove a espada após derrotar o monstro
            monster2.alive = false; // Define o monstro como morto
            monster2.x = -100;
            monster2.y = -100;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        } else {
            console.log('Você encontrou um monstro!');
            hasSword = false;
            // Adicione aqui o que acontece quando o jogador encontra o monstro sem a espada
            loseLife(); // Chama a função para perder vida
            player.x = 50;
            player.y = 50;
        }
}else if ((player.x < monster3.x + monster3.width &&
    player.x + player.width > monster3.x &&
    player.y < monster3.y + monster3.height &&
    player.y + player.height > monster3.y) ) {
        if (hasSword) {
            console.log('Você matou o monstro!');
            defeatedMonsters++;
            // Adicione aqui o que acontece quando o jogador mata o monstro
            hasSword = false; // Remove a espada após derrotar o monstro
            monster3.alive = false; // Define o monstro como morto
            monster3.x = -1100;
            monster3.y = -1100;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        } else {
            console.log('Você encontrou um monstro!');
            hasSword = false;
            // Adicione aqui o que acontece quando o jogador encontra o monstro sem a espada
            loseLife(); // Chama a função para perder vida
            player.x = 50;
            player.y = 50;
        }
}else if ((player.x < monster4.x + monster4.width &&
    player.x + player.width > monster4.x &&
    player.y < monster4.y + monster4.height &&
    player.y + player.height > monster4.y) ) {
        if (hasSword) {
            console.log('Você matou o monstro!');
            defeatedMonsters++;
            // Adicione aqui o que acontece quando o jogador mata o monstro
            hasSword = false; // Remove a espada após derrotar o monstro
            monster4.alive = false; // Define o monstro como morto
            monster4.x = -1100;
            monster4.y = -1100;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        } else {
            console.log('Você encontrou um monstro!');
            hasSword = false;
            // Adicione aqui o que acontece quando o jogador encontra o monstro sem a espada
            loseLife(); // Chama a função para perder vida
            player.x = 50;
            player.y = 50;
        }
}else if ((player.x < monster5.x + monster5.width &&
    player.x + player.width > monster5.x &&
    player.y < monster5.y + monster5.height &&
    player.y + player.height > monster5.y)) {
        if (hasSword) {
            console.log('Você matou o monstro!');
            defeatedMonsters++;
            // Adicione aqui o que acontece quando o jogador mata o monstro
            hasSword = false; // Remove a espada após derrotar o monstro
            monster5.alive = false; // Define o monstro como morto
            monster5.x = -1100;
            monster5.y = -1100;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        } else {
            console.log('Você encontrou um monstro!');
            hasSword = false;
            // Adicione aqui o que acontece quando o jogador encontra o monstro sem a espada
            loseLife(); // Chama a função para perder vida
            player.x = 50;
            player.y = 50;
        }
}else if ((player.x < monster6.x + monster6.width &&
    player.x + player.width > monster6.x &&
    player.y < monster6.y + monster6.height &&
    player.y + player.height > monster6.y)) {
        if (hasSword) {
            console.log('Você matou o monstro!');
            defeatedMonsters++;
            // Adicione aqui o que acontece quando o jogador mata o monstro
            hasSword = false; // Remove a espada após derrotar o monstro
            monster6.alive = false; // Define o monstro como morto
            monster6.x = -1100;
            monster6.y = -1100;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        } else {
            console.log('Você encontrou um monstro!');
            hasSword = false;
            // Adicione aqui o que acontece quando o jogador encontra o monstro sem a espada
            loseLife(); // Chama a função para perder vida
            player.x = 50;
            player.y = 50;
        }
}else if ((player.x < monster7.x + monster7.width &&
    player.x + player.width > monster7.x &&
    player.y < monster7.y + monster7.height &&
    player.y + player.height > monster7.y)) {
        if (hasSword) {
            console.log('Você matou o monstro!');
            defeatedMonsters++;
            // Adicione aqui o que acontece quando o jogador mata o monstro
            hasSword = false; // Remove a espada após derrotar o monstro
            monster7.alive = false; // Define o monstro como morto
            monster7.x = -1100;
            monster7.y = -1100;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        } else {
            console.log('Você encontrou um monstro!');
            hasSword = false;
            // Adicione aqui o que acontece quando o jogador encontra o monstro sem a espada
            loseLife(); // Chama a função para perder vida
            player.x = 50;
            player.y = 50;
        }
}else if ((player.x < monster8.x + monster8.width &&
    player.x + player.width > monster8.x &&
    player.y < monster8.y + monster8.height &&
    player.y + player.height > monster8.y)) {
        if (hasSword) {
            console.log('Você matou o monstro!');
            defeatedMonsters++;
            // Adicione aqui o que acontece quando o jogador mata o monstro
            hasSword = false; // Remove a espada após derrotar o monstro
            monster8.alive = false; // Define o monstro como morto
            monster8.x = -1100;
            monster8.y = -1100;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        } else {
            console.log('Você encontrou um monstro!');
            hasSword = false;
            // Adicione aqui o que acontece quando o jogador encontra o monstro sem a espada
            loseLife(); // Chama a função para perder vida
            player.x = 50;
            player.y = 50;
        }
}



    // Colisão com a chave
    if (player.x < key.x + key.width &&
        player.x + player.width > key.x &&
        player.y < key.y + key.height &&
        player.y + player.height > key.y && collectedKeys === 0) { // Verifica se a chave não foi coletada antes
            console.log('Você encontrou uma chave!');
            key.width=0;
            key.height=0;
            // Adicione aqui o que acontece quando o jogador encontra a chave, como abrir a porta, por exemplo
            collectedKeys++; // Incrementa o número de chaves coletadas
            totalKeys++;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        }
        // Colisão com a chave 2
    if (player.x < key2.x + key2.width &&
        player.x + player.width > key2.x &&
        player.y < key2.y + key2.height &&
        player.y + player.height > key2.y && collectedKeys2 === 0) { // Verifica se a chave não foi coletada antes
            console.log('Você encontrou uma chave!');
            key2.width=0;
            key2.height=0;
            // Adicione aqui o que acontece quando o jogador encontra a chave, como abrir a porta, por exemplo
            collectedKeys2++; // Incrementa o número de chaves coletadas
            totalKeys++;
            document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

        }
        if (player.x < key3.x + key3.width &&
            player.x + player.width > key3.x &&
            player.y < key3.y + key3.height &&
            player.y + player.height > key3.y && collectedKeys3 === 0) { // Verifica se a chave não foi coletada antes
                console.log('Você encontrou uma chave!');
                key3.width=0;
                key3.height=0;
                // Adicione aqui o que acontece quando o jogador encontra a chave, como abrir a porta, por exemplo
                collectedKeys3++; // Incrementa o número de chaves coletadas
                totalKeys++;
                document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

            }
            if (player.x < key4.x + key4.width &&
                player.x + player.width > key4.x &&
                player.y < key4.y + key4.height &&
                player.y + player.height > key4.y && collectedKeys4 === 0) { // Verifica se a chave não foi coletada antes
                    console.log('Você encontrou uma chave!');
                    key4.width=0;
                    key4.height=0;
                    // Adicione aqui o que acontece quando o jogador encontra a chave, como abrir a porta, por exemplo
                    collectedKeys4++; // Incrementa o número de chaves coletadas
                    totalKeys++;
                    document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar

                }
     // Colisão com a porta (fim do jogo)
     if (player.x < door.x + door.width &&
        player.x + player.width > door.x &&
        player.y < door.y + door.height &&
        player.y + player.height > door.y) {
            if (totalKeys === 4) {
                gameOver = true;
                console.log('Você escapou!');
                document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 100 + defeatedMonsters * 50)+'     Monstros derrotados: ' + defeatedMonsters;; // Atualiza o placar
                document.getElementById('escapou').style.display = 'block';
            } else {
                player.x=player.x-10;

                document.getElementById('notEnoughKeys').style.display = 'block';
            }
        }
}
    


// Função de desenho
export function draw() {
    // Limpa o canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    if (images.length === 0) return; // Verifica se as imagens foram carregadas

    // Desenha o jogador
    ctx.drawImage(images[0], player.x, player.y, player.width, player.height);

    // Desenha as paredes do labirinto
    ctx.fillStyle = 'gray';
    walls.concat(maze).forEach(wall => {
        ctx.drawImage(images[1], wall.x, wall.y, wall.width, wall.height);
    });

    // Desenha o baú
    ctx.drawImage(images[3], chest.x, chest.y, chest.width, chest.height);

    // Desenha o monstro
    ctx.drawImage(images[4], monster.x, monster.y, monster.width, monster.height);
    ctx.drawImage(images[4], monster1.x, monster1.y, monster1.width, monster1.height);
    ctx.drawImage(images[4], monster2.x, monster2.y, monster2.width, monster2.height);
    ctx.drawImage(images[4], monster3.x, monster3.y, monster3.width, monster3.height);
    ctx.drawImage(images[4], monster4.x, monster4.y, monster4.width, monster4.height);
    ctx.drawImage(images[4], monster5.x, monster5.y, monster5.width, monster5.height);
    ctx.drawImage(images[4], monster6.x, monster6.y, monster6.width, monster6.height);
    ctx.drawImage(images[4], monster7.x, monster7.y, monster7.width, monster7.height);
    ctx.drawImage(images[4], monster8.x, monster8.y, monster8.width, monster8.height);
    // Desenha a chave
    ctx.drawImage(images[5], key.x, key.y, key.width, key.height);
    ctx.drawImage(images[5], key2.x, key2.y, key2.width, key2.height);
    ctx.drawImage(images[5], key3.x, key3.y, key3.width, key3.height);
    ctx.drawImage(images[5], key4.x, key4.y, key4.width, key4.height);
    // Desenha a porta
    ctx.fillStyle = 'green';
    ctx.drawImage(images[2], door.x, door.y, door.width, door.height);

    // Desenha a espada se o jogador a tiver
    if (hasSword) {
        ctx.drawImage(images[6], sword.x, sword.y, sword.width, sword.height);
    }

    if (gameOver) {
        player.x=player.x-10;
        ctx.fillStyle = 'black';
        ctx.font = '30px Arial';
        document.getElementById("escapou").style.display = "block";
        gameOver=false;
    }
}
