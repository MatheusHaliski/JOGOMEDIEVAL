//game.js
import { player, tileSize, tileSrcSize,maze,T_HEIGHT,T_WIDTH } from './maze.js';
import { updateEnemies,enemy, enemy2, enemy3,enemy4,renderEnemies } from './enemy.js';
import { updateCamera,cam } from './camera.js';
import { updatePlayer,renderPlayer } from './player.js';
import { mvLeft1, mvRight1, mvUp1, mvDown1,handleKeyDown,handleKeyUp } from './controls.js';
import { walls } from './maze.js';
export let playerLifes = 3;
export let mazeCompleted = false;
export let keys = [{ x: 100, y: 200, collected: false },{ x: 500, y: 100, collected: false},{ x: 670, y: 300, collected: false},
    { x: 770, y: 300, collected: false},{ x: 920, y: 230, collected: false}
];
export let portal = { x: 300, y: 300, width: tileSize, height: tileSize, isOpen: false };
export let score = 0;
var totalKeys = 0;
var attemptedPortalEntry = false;
var attemptedPortalEntry2 = false;
var img = new Image();
var img2 = new Image();
var img3 = new Image();
var img4 = new Image();
var img5 = new Image();
img.src = "img/img.png";
img2.src = "img/monster.png";
img3.src = "img/monster.png";
img4.src="img/monster.png";
img5.src="img/monster.png";
var keyImage = new Image();
keyImage.src = "img/key.png";

var portalClosedImage = new Image();
portalClosedImage.src = "img/portal_closed.png";

var portalOpenImage = new Image();
portalOpenImage.src = "img/portal_open.png";
export function initGame() {
    updateUI();
}
var cnv = document.querySelector("canvas"); // Referência ao canvas
var ctx = cnv.getContext("2d"); // Definindo o contexto 2D
export function updateGame() {
    // Atualização do jogador, inimigos, câmeras, colisões, e checagens de portal
    updatePlayer();
    updateEnemies();
    checkKeyCollision();
    checkPortalCollision();
    updateCamera();
    renderPlayer(ctx);
    
}
function loseLife() {
    const hearts = document.querySelectorAll('.heart');

    if (playerLifes == 3) {
        hearts[2].style.display = 'none';
    }else if(playerLifes == 2){
        hearts[1].style.display = 'none';
    }else if(playerLifes == 1){
        hearts[0].style.display = 'none';
    }
}
export   // Função para verificar se o jogador colidiu com uma chave
function checkKeyCollision() {
    keys.forEach(function(key) {
        if (!key.collected && player.x < key.x + 32 &&
            player.x + player.width > key.x &&
            player.y < key.y + 32 &&
            player.y + player.height > key.y) {
                totalKeys+=1;
                document.getElementById('score').textContent = 'Pontos: ' + ((totalKeys) * 150); // Atualiza o placar
                key.collected = true;
        }
    });
}

export function checkPortalCollision() {
    if (player.x < portal.x + portal.width &&
        player.x + player.width > portal.x &&
        player.y < portal.y + portal.height &&
        player.y + player.height > portal.y) {
        
        if (checkAllKeysCollected() && !attemptedPortalEntry2) {
            attemptedPortalEntry2 = true;
            portal.isOpen = true;
            alert("Portal aberto! Você venceu!");
        } else {
            if (!attemptedPortalEntry) {
                attemptedPortalEntry = true;
                if (player.x + player.width > portal.x && player.x < portal.x + portal.width) {
                    if (player.x + player.width / 2 < portal.x + portal.width / 2) {
                        player.x = portal.x - player.width - 1;
                    } else {
                        player.x = portal.x + portal.width + 1;
                    }
                }
                if (player.y + player.height > portal.y && player.y < portal.y + portal.height) {
                    if (player.y + player.height / 2 < portal.y + portal.height / 2) {
                        player.y = portal.y - player.height - 1;
                    } else {
                        player.y = portal.y + portal.height + 1;
                    }
                }
                alert("O portal está fechado. Encontre todas as chaves.");
            }
        }
    } else {
        attemptedPortalEntry = false;
        attemptedPortalEntry2 = false;
    }
}

function checkAllKeysCollected() {
    return keys.every(key => key.collected);
}

export function updateUI() {
    const heartsDiv = document.getElementById("hearts");
    heartsDiv.innerHTML = "";
    for (let i = 0; i < playerLifes; i++) {
        const heartImg = document.createElement("img");
        heartImg.src = "img/coracao.png";
        heartsDiv.appendChild(heartImg);
    }

    const scoreDiv = document.getElementById("score");
    scoreDiv.textContent = "Score: " + score;
}

export function renderGame() {
    // Renderização do jogo
    var cnv = document.querySelector("canvas"); // Referência ao canvas
var ctx = cnv.getContext("2d"); // Definindo o contexto 2D
    ctx.clearRect(0, 0, 800, 640);
    ctx.save();
    for (var row in maze){        
        for (var column in maze[row]){     
            var tile = maze[row][column];
            var x = column * tileSize;
            var y = row * tileSize;
           
            ctx.drawImage(
                img,
                tile * tileSrcSize, 0, tileSrcSize, tileSrcSize,
                x, y, tileSize, tileSize
            );         
        }
        for (var row in maze){        
            for (var column in maze[row]){     
                var tile = maze[row][column];
                var x = column * tileSize;
                var y = row * tileSize;
               
                ctx.drawImage(
                    img,
                    tile * tileSrcSize, 0, tileSrcSize, tileSrcSize,
                    x, y, tileSize, tileSize
                );         
            }             
        }              
    } 
    
    // Desenhar o jogador
    ctx.drawImage(
        img,
        player.srcX, player.srcY, player.width, player.height,
        player.x, player.y, player.width, player.height
    );

    // Desenhar o inimigo
    ctx.drawImage(
        img2,
        enemy.x, enemy.y
        , 50, 50
    );
     // Desenhar o inimigo
     ctx.drawImage(
        img3,
        enemy2.x, enemy2.y
        , 50, 50
    );
    ctx.drawImage(
        img4,
        enemy3.x, enemy3.y
        , 50, 50
    );
    ctx.drawImage(
        img5,
        enemy4.x, enemy4.y
        , 50, 50
    );
    // Desenhar as chaves
    keys.forEach(function(key) {
        if (!key.collected) {
            ctx.drawImage(
                keyImage,
                key.x, key.y, 32, 32
            );
        }
    });

    // Desenhar o portal
    if (portal.isOpen) {
        // Desenhar o portal aberto
        ctx.drawImage(
            portalOpenImage,
            portal.x, portal.y, tileSize, tileSize
        );
    } else {
        // Desenhar o portal fechado
        ctx.drawImage(
            portalClosedImage,
            portal.x, portal.y, tileSize, tileSize
        );
    }
    
    // Desenhar corações de vida
    var coracaoImg = new Image();
    coracaoImg.src = "img/coracao.png";
    for (var i = 0; i < playerLifes; i++){
        ctx.drawImage(
            coracaoImg,
            0, 0, 32, 32,
            (T_WIDTH + 10) + (i * 32), 10, 32, 32
        );
    }
    ctx.restore();
}

export function resetGame() {
    playerLifes = 3;
    score = 0;
    player.x = tileSize + 2;
    player.y = tileSize + 2;
    enemy.x = 100;
    enemy.y = 100;
    enemy2.x = 200;
    enemy2.y = 200;
    enemy3.x = 300;
    enemy3.y = 300;
    enemy4.x = 530;
    enemy4.y = 300;
    keys.forEach(key => key.collected = false);
    portal.isOpen = false;
    updateUI();
}

function blockRectangle(objA, objB){
    var distX = (objA.x + objA.width/2) - (objB.x + objB.width/2);
    var distY = (objA.y + objA.height/2) - (objB.y + objB.height/2);

    var sumWidth = (objA.width + objB.width)/2;
    var sumHeight = (objA.height + objB.height)/2;

    if(Math.abs(distX) < sumWidth && Math.abs(distY) < sumHeight){
        var overlapX = sumWidth - Math.abs(distX);
        var overlapY = sumHeight - Math.abs(distY);

        if(overlapX > overlapY){
            objA.y = distY > 0 ? objA.y + overlapY : objA.y - overlapY;
        }else{
            objA.x = distX > 0 ? objA.x + overlapX : objA.x - overlapX;
        }
    }
}

export function update(){               //atualizar elementos do jogo
    if (mvLeft1 && !mvRight1){
        player.x -= player.speed;
        player.srcY = tileSrcSize + player.height * 2;
    } else if (mvRight1 && !mvLeft1){
        player.x += player.speed;
        player.srcY = tileSrcSize + player.height * 3;
    }
    if (mvUp1 && !mvDown1){
        player.y -= player.speed;
        player.srcY = tileSrcSize + player.height * 1;
    } else if (mvDown1 && !mvUp1) {
        player.y += player.speed;
        player.srcY = tileSrcSize + player.height * 0;
    }

    if (mvLeft1 || mvRight1 || mvUp1 || mvDown1){
        player.countAnim++;
        if (player.countAnim >= 32){
            player.countAnim = 0;
        }
        player.srcX = Math.floor(player.countAnim / 4) * player.width;
    } else {
        player.srcX = 0;
        player.countAnim = 0;
    }

    // Atualização da posição do inimigo
    if (player.x < enemy.x){
        enemy.x -= 0.11;
    } else if (player.x > enemy.x){
        enemy.x += 0.11;
    }
    if (player.y < enemy.y){
        enemy.y -=0.11;
    } else if (player.y > enemy.y){
        enemy.y += 0.11;
    }
if (player.x < enemy2.x){
         enemy2.x -= 0.11;
    } else if (player.x > enemy2.x){
        enemy2.x += 0.11;
    }
    if (player.y < enemy2.y){
        enemy2.y -= 0.11;
    } else if (player.y > enemy2.y){
        enemy2.y += 0.11;
    }

    if (player.x < enemy3.x){
         enemy3.x -= 0.11;
    } else if (player.x > enemy3.x){
        enemy3.x += 0.11;
    }
    if (player.y < enemy3.y){
        enemy3.y -= 0.11;
    } else if (player.y > enemy3.y){
        enemy3.y += 0.11;
    }
    if (player.x < enemy4.x){
        enemy3.x -= 0.12;
   } else if (player.x > enemy4.x){
       enemy3.x += 0.12;
   }
   if (player.y < enemy4.y){
       enemy4.y -= 0.12;
   } else if (player.y > enemy4.y){
       enemy4.y += 0.12;
   }
    // Checagem de colisão entre jogador e inimigo
    if (player.x < enemy.x + enemy.width &&
        player.x + player.width > enemy.x &&
        player.y < enemy.y + enemy.height &&
        player.y + player.height > enemy.y){
            playerLifes -= 1;
            loseLife();
            if (playerLifes === 0){
                // Game over
                alert("Você perdeu!");
                location.reload(); // Recarrega a página para reiniciar o jogo
            }
            // Colocar o jogador na posição inicial
            player.x = tileSize + 2;
            player.y = tileSize + 2;
    }
    if (player.x < enemy2.x + enemy2.width &&
        player.x + player.width > enemy2.x &&
        player.y < enemy2.y + enemy2.height &&
        player.y + player.height > enemy2.y){
            playerLifes -= 1;
            loseLife();
            if (playerLifes === 0){
                // Game over
                alert("Você perdeu!");
                location.reload(); // Recarrega a página para reiniciar o jogo
            }
            // Colocar o jogador na posição inicial
            player.x = tileSize + 2;
            player.y = tileSize + 2;
    }
    if (player.x < enemy3.x + enemy3.width &&
        player.x + player.width > enemy3.x &&
        player.y < enemy3.y + enemy3.height &&
        player.y + player.height > enemy3.y){
            playerLifes -= 1;
            loseLife();
            if (playerLifes === 0){
                // Game over
                alert("Você perdeu!");
                location.reload(); // Recarrega a página para reiniciar o jogo
            }
            // Colocar o jogador na posição inicial
            player.x = tileSize + 2;
            player.y = tileSize + 2;
    }
    if (player.x < enemy4.x + enemy4.width &&
        player.x + player.width > enemy4.x &&
        player.y < enemy4.y + enemy4.height &&
        player.y + player.height > enemy4.y){
            playerLifes -= 1;
            loseLife();
            if (playerLifes === 0){
                // Game over
                alert("Você perdeu!");
                location.reload(); // Recarrega a página para reiniciar o jogo
            }
            // Colocar o jogador na posição inicial
            player.x = tileSize + 2;
            player.y = tileSize + 2;
    }
    // Checagem de colisão com as paredes
    for (var i in walls){
        var wall = walls[i];
        blockRectangle(player, wall);
        blockRectangle(enemy, wall);
        blockRectangle(enemy2, wall);
        blockRectangle(enemy3, wall);
        blockRectangle(enemy4, wall);
    }

    // Checagem de vitória
    if (player.x > T_WIDTH - tileSize && player.y > T_HEIGHT - tileSize && !mazeCompleted){
        mazeCompleted = true;
        alert("Você ganhou!");
    }
    

    // Checar colisão com as chaves
    checkKeyCollision();

    // Checar colisão com o portal
    checkPortalCollision();

    // Atualização da posição da câmera
    if (player.x < cam.innerLeftBoundary()){
        cam.x = player.x - (cam.width * 0.25);
    }
    if (player.y < cam.innerTopBoundary()){
        cam.y = player.y - (cam.height * 0.25);
    }
    if (player.x + player.width > cam.innerRightBoundary()){
        cam.x = player.x + player.width - (cam.width * 0.75);
    }

    cam.x = Math.max(0, Math.min(T_WIDTH - cam.width, cam.x));
    cam.y = Math.max(0, Math.min(T_HEIGHT - cam.height, cam.y));
}       