// player.js
import { tileSize, tileSrcSize } from './maze.js';
import { LEFT, UP, RIGHT, DOWN, mvLeft, mvUp, mvRight, mvDown } from './constants.js';
import { handleKeyDown, handleKeyUp } from './controls.js';
let playerImage = new Image();
playerImage.src = "img/img.png";

export let player = {
    x: tileSize + 42,
    y: 112,
    width: 24,
    height: 32,
    speed: 6,
    srcX: 110,
    srcY: tileSrcSize,
    countAnim: 0
};

export function initPlayer() {
    // Inicializações do jogador, se necessárias
}

export function updatePlayer() {
    // Atualizações do jogador, movimentação, animação e colisões
    if (mvLeft && !mvRight) {
        player.x -= player.speed;
        player.srcY = tileSrcSize + player.height * 2;
    } else if (mvRight && !mvLeft) {
        player.x += player.speed;
        player.srcY = tileSrcSize + player.height * 3;
    }
    if (mvUp && !mvDown) {
        player.y -= player.speed;
        player.srcY = tileSrcSize + player.height * 1;
    } else if (mvDown && !mvUp) {
        player.y += player.speed;
        player.srcY = tileSrcSize + player.height * 0;
    }

    if (mvLeft || mvRight || mvUp || mvDown) {
        player.countAnim++;
        if (player.countAnim >= 32) {
            player.countAnim = 0;
        }
        player.srcX = Math.floor(player.countAnim / 4) * player.width;
    } else {
        player.srcX = 0;
        player.countAnim = 0;
    }
}

export function renderPlayer(ctx) {
    window.addEventListener("keydown", handleKeyDown, false);
window.addEventListener("keyup", handleKeyUp, false);
    playerImage = new Image();
    playerImage.src = "img/img.png";
    ctx.drawImage(
        playerImage,
        111, 55, player.width, player.height
    );
}
