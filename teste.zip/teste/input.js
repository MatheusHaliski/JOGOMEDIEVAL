
export let mvLeft = false;
export let mvUp = false;
export let mvRight =false;
export let mvDown =false;
export const LEFT = 37, UP = 38, RIGHT = 39, DOWN = 40;

export function handleKeydown(e) {
    var key = e.keyCode;
    switch (key) {
        case LEFT:
            mvLeft = true;
            break;
        case UP:
            mvUp = true;
            break;
        case RIGHT:
            mvRight = true;
            break;
        case DOWN:
            mvDown = true;
            break;
    }
}

export function handleKeyup(e) {
    var key = e.keyCode;
    switch (key) {
        case LEFT:
            mvLeft = false;
            break;
        case UP:
            mvUp = false;
            break;
        case RIGHT:
            mvRight = false;
            break;
        case DOWN:
            mvDown = false;
            break;
    }
}
