// constants.js
export var LEFT = 37, UP = 38, RIGHT = 39, DOWN = 40;
export let mvUp = false;
export let mvDown = false;
export let mvRight = false;
export let mvLeft = false;
