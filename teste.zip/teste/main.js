import { initPlayer, updatePlayer, renderPlayer } from './player.js';
import {  updateEnemies, renderEnemies } from './enemy.js';
import { initMaze, walls } from './maze.js';
import { cam, updateCamera } from './camera.js';
import { handleKeyDown, handleKeyUp } from './controls.js';
import { initGame, updateGame,update, renderGame, checkKeyCollision, checkPortalCollision, updateUI } from './game.js';

// Inicialização do jogo
window.addEventListener("load", () => {



    // Exibir o modal inicial
    const modalStart = document.getElementById("modal-start");
    modalStart.style.display = "block";

    // Adicionar evento ao botão de iniciar o jogo
    document.getElementById("btn-play").addEventListener("click", () => {
        modalStart.style.display = "none";
        requestAnimationFrame(loop);
    });

    // Adicionar eventos aos botões do modal de fim de jogo
    document.getElementById("btn-restart").addEventListener("click", () => {
        resetGame();
        const modalGameOver = document.getElementById("modal-game-over");
        modalGameOver.style.display = "none";
    });

    // Adicionar eventos aos botões de modais
    document.querySelectorAll(".close").forEach(el => {
        el.addEventListener("click", () => {
            const modal = el.closest(".modal");
            modal.style.display = "none";
        });
    });

    document.getElementById("btn-about").addEventListener("click", () => {
        const modalAbout = document.getElementById("modal-about");
        modalAbout.style.display = "block";
    });
}, false);

var cnv = document.querySelector("canvas"); // Referência ao canvas
var ctx = cnv.getContext("2d"); // Definindo o contexto 2D
function loop(){   
    console.log('entrou'); 
    updatePlayer();
    renderPlayer(ctx);
    renderGame();
    update();      
    requestAnimationFrame(loop);          //chamar de novo o loop
} 
loop();
window.addEventListener("keydown", handleKeyDown, false);
window.addEventListener("keyup", handleKeyUp, false);