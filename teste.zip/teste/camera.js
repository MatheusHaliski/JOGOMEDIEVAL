import { player, T_WIDTH, T_HEIGHT } from './maze.js';
var cnv = document.querySelector("canvas");     //referencia ao canvas
var ctx = cnv.getContext("2d"); 
var WIDTH = cnv.width, HEIGHT = cnv.height;
export var cam = {
    x: 0,
    y: 0,
    width: WIDTH,
    height: HEIGHT,
    innerLeftBoundary: function(){
        return this.x + (this.width*0.25);
    },
    innerTopBoundary: function(){
        return this.y + (this.height*0.25);
    },
    innerRightBoundary: function(){
        return this.x + (this.width*0.75);
    },
    innerBottomBoundary: function(){
        return this.y + (this.height*0.75);
    }
};
export function updateCamera() {
    if (player.x < cam.innerLeftBoundary()) {
        cam.x = player.x - (cam.width * 0.25);
    }
    if (player.y < cam.innerTopBoundary()) {
        cam.y = player.y - (cam.height * 0.25);
    }
    if (player.x + player.width > cam.innerRightBoundary()) {
        cam.x = player.x + player.width - (cam.width * 0.75);
    }

    cam.x = Math.max(0, Math.min(T_WIDTH - cam.width, cam.x));
    cam.y = Math.max(0, Math.min(T_HEIGHT - cam.height, cam.y));
}
