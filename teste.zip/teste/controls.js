//controls.js
import { LEFT, UP, RIGHT, DOWN, mvLeft, mvUp, mvRight, mvDown } from './constants.js';
export let mvDown1 = false;
export let mvLeft1 = false;
export let mvRight1 = false;
export let mvUp1 = false;
export function handleKeyDown(e) {
    console.log('entrouaquiii');
    var key = e.keyCode;
    switch(key) {
        case LEFT:
            console.log('DFDFDF');
            mvLeft1 = true;
            break;
        case UP:
            mvUp1 = true;
            console.log('DFDFDF');
            break;
        case RIGHT:
            mvRight1 = true;
            console.log('DFDFDF');
            break;
        case DOWN:
            mvDown1 = true;
            console.log('entrou123123');
            break;
    }
}

export function handleKeyUp(e) {
    var key = e.keyCode;
    switch(key) {
        case LEFT:
            mvLeft1 = false;
            console.log('KKKKK');
            break;
        case UP:
            mvUp1 = false;
            console.log('AAAA');
            break;
        case RIGHT:
            mvRight1 = false;
            console.log('BBBB');
            break;
        case DOWN:
            mvDown1 = false;
            console.log('entrou123123');
            break;
    }
}
