export let enemy = { x: 530, y: 150, width: 50, height: 50 };
export let enemy2 = { x: 200, y: 300, width: 50, height: 50 };
export let enemy3 = { x: 500, y: 300, width: 50, height: 50 };
export let enemy4 = { x: 530, y: 400, width: 50, height: 50 };
import { player } from "./maze.js";

export function updateEnemies() {
    // Atualizar a posição dos inimigos
    updateEnemyPosition(enemy);
    updateEnemyPosition(enemy2);
    updateEnemyPosition(enemy3);
    updateEnemyPosition(enemy4);
}

function updateEnemyPosition(enemy) {
    if (player.x < enemy.x) {
        enemy.x -= 0.5;
    }
    if (player.x > enemy.x) {
        enemy.x += 0.5;
    }
    if (player.y < enemy.y) {
        enemy.y -= 0.5;
    }
    if (player.y > enemy.y) {
        enemy.y += 0.5;
    }
}

export function renderEnemies() {
    var cnv = document.querySelector("canvas"); // Referência ao canvas
    var ctx = cnv.getContext("2d"); // Definindo o contexto 2D
    var enemyImage = new Image();
    enemyImage.src =  "img/monster.png";
    ctx.drawImage(enemyImage, enemy.x, enemy.y, enemy.width, enemy.height);
    ctx.drawImage(enemyImage, enemy2.x, enemy2.y, enemy2.width, enemy2.height);
    ctx.drawImage(enemyImage, enemy3.x, enemy3.y, enemy3.width, enemy3.height);
    ctx.drawImage(enemyImage, enemy4.x, enemy4.y, enemy4.width, enemy4.height);
}
