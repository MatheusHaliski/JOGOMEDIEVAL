//game.js

import { loadImages, update, draw, setup } from './gameFunctions.js';

async function main() {
    const imagePaths = ['character.png', 'wall.png', 'door.png','chest.png','monster.png','key.png','sword.png'];
    await loadImages(imagePaths); 

    setup();
    
    // Loop principal do jogo
    function gameLoop() {
        update();
        draw();
        requestAnimationFrame(gameLoop);
    }
    
    gameLoop();
}

main();
